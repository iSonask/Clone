# iOS-Geofence-Swift
How to implement virtual boundaries in the real world?
A simple example project explaining how to set up a Geofence and trigger an action when the user enters / leaves the area.
